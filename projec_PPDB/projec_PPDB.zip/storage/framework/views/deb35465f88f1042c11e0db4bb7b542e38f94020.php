
<?php $__env->startSection('content'); ?>
    <div class="start">
        <div class="main-start">
            <h2><b>Admin</b></h2>
        </div>
        <div class="main-title">

            <div class="d-flex">
                <box-icon name='minus'></box-icon>
                <p> Hi, Admin</p>
            </div>
            <p style="font-size: 15px">Selamat Datang</p>


            <div class="cardp" style="background-color: white">

                <img src="<?php echo e(asset('assets/img/' . $student['foto'])); ?>">
                <p> Nama Bank : <?php if($student['nama_bank'] == 'lainnya'): ?>
                    <?php echo e($student->nama_bank_text); ?>

                <?php else: ?>
                    <?php echo e($student->nama_bank); ?>

                
                <?php endif; ?></p>
                <p>Nama Pemilik Rekening : <?php echo e($student->nama_pemilik); ?></p>
                <p>Nominal : <?php echo e($student->nominal); ?></p>
                <a class="btn btn-primary" href="<?php echo e(route('pembayaran')); ?>">Kembali</a>
            </div>
            <div class="">
               
            </div>
        </div>
    </div>
    </div>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DEV\xampp\htdocs\My-Project\projec_PPDB\resources\views/dashboard/lihat.blade.php ENDPATH**/ ?>