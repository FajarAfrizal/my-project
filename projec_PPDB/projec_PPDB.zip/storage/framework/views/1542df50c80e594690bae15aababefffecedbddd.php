
<?php $__env->startSection('content'); ?>
<div class="start">
    <div class="main-start">
        <h2><b>Admin</b></h2>
    </div>
        <div class="main-title">
            
            <div class="d-flex">
                <box-icon name='minus'></box-icon>
                <p> Hi, Admin</p>
            </div>
            <p style="font-size: 15px">Selamat Datang</p>


            <div class="panjul" style="background-color: white">
                <ul>
                    <li>NISN: <?php echo e($student->nisn); ?></li>
                    <li>Nama : <?php echo e($student->nama); ?></li>
                    <li>Jenis kelamin : <?php echo e($student->kelamin); ?></li>
                    <li>Asal_sekolah : <?php echo e($student->asal_sekolah); ?></li>
                    <li>Email : <?php echo e($student->email); ?></li>
                    <li>No Hp : <?php echo e($student->no_hp); ?></li>
                    <li>No Hp Ayah : <?php echo e($student->no_hp_ayah); ?></li>
                    <li>No Hp Ibu : <?php echo e($student->no_hp_ibu); ?></li>
                    <a class="btn btn-primary" href="<?php echo e(route('pembayaran')); ?>">Kembali</a>
                </ul>
            </div>
        </div>
</div>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DEV\xampp\htdocs\My-Project\projec_PPDB\resources\views/dashboard/detail.blade.php ENDPATH**/ ?>