
<?php $__env->startSection('content'); ?>
    <div class="start">
        <?php if(Auth::user()->role == 'admin'): ?>
            <div class="main-start">
                <h2><b>Admin</b></h2>
            </div>
            <div class="main-title">
                <?php if($message = Session::get('warning')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="d-flex">
                    <box-icon name='minus'></box-icon>
                    <p> Hi, Admin</p>
                </div>
                <p style="font-size: 15px">Selamat Datang</p>


                <div class="panjul" style="background-color: orange">
                    <p>Silahkan mengecek data pendaftaran beserta bukti pembayaran para calon siswa</p>
                </div>
            </div>
        <?php else: ?>
            <div class="main-start">
                <h2><b>Student</b></h2>
            </div>

            <div class="main-title">
                <?php if($message = Session::get('warning')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="d-flex">
                    <box-icon name='minus'></box-icon>
                    <p> Hi, <?php echo e(Auth::user()->nama); ?></p>
                </div>
                <p style="font-size: 15px">Selamat Datang</p>
                <div class="d-flex">
                    <div class="justify-items-left">
                        <div class="card mb-5">
                            <div class="card-body bg-white "
                                style="background-image: linear-gradient(to right, #263dc0, #162a60, #130153);color:white;">
                                <h1 class="mb-3"><?php echo e(Auth::user()->nama); ?></h1>
                                <p><b>Nomor Seleksi </b>:<?php echo e(Auth::user()->id); ?></p>
                                <p><b>NISN </b>:<?php echo e(Auth::user()->nisn); ?></p>
                                <p><b>Nama </b>:<?php echo e(Auth::user()->nama); ?></p>
                                <p><b>Nomor Hp </b>:<?php echo e(Auth::user()->no_hp); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if($student === null): ?>
                <?php elseif($student['status'] == 1): ?>
                    <div class="stenly" style="background-color: rgb(100, 255, 100)">
                        <p>Pembayaran telah di berhasil</p>
                    </div>
                <?php elseif($student['status']== 0): ?>
                    <div class="panjul" style="background-color: orange">
                        <p>Pembayaran sedang di verivikasi, harap tunggu informasi selanjutnya</p>
                    </div>
                    <div class="stenly" style="background-color: rgb(100, 255, 100)">
                        <p>Pembayarn telah dilakukan silahkan menunggu admin validasi</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DEV\xampp\htdocs\My-Project\projec_PPDB\resources\views/dashboard/index.blade.php ENDPATH**/ ?>