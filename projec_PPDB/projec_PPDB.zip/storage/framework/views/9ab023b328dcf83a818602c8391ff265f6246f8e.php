
<?php $__env->startSection('content'); ?>
    <div class="start">
        <?php if(Auth::user()->role == 'admin'): ?>
            <div class="main-start">
                <h2><b>Admin</b></h2>
            </div>
            <table class="table table-bordered border-primary table-light">
                <tr>
                    <th>No</th>
                    <th>Nomor Registrasi</th>
                    <th>Bukti Pembayaran</th>
                    <th>Detail Pendaftaran</th>
                    <th>Aksi</th>
                </tr>
                <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-secondary">
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->user_id); ?></td>
                        <td>
                            <a href="<?php echo e(route('lihat', $item->id)); ?>">Lihat</a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('detail', $item->user_id)); ?>">Detail</a>
                        </td>
                        <td>
                            <?php if($item['status'] == 1): ?>
                                <p>Validasi</p>
                            <?php elseif($item['status'] == 2): ?>
                                <p>Tolak</p>
                            <?php else: ?>
                                <div class="d-flex justify-content-end">

                                    <form action="<?php echo e(route('validasi', $item->id)); ?>" method="POST" class="">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-success ">Validasi</button>
                                    </form>
                                    <form action="<?php echo e(route('tolak', $item->id)); ?>" method="POST" class="">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-danger ml-3">Tolak</button>
                                    </form>

                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php else: ?>
            <div class="main-start">
                <h2><b>Student</b></h2>
            </div>
            <?php if($student == null): ?>
            <div class="main-title">
                <div class="d-flex">
                    <box-icon name='minus'></box-icon>
                    <p> Pembayaran</p>
                </div>
                <p style="font-size: 15px">Silahkan upload ukti pembayaran anda di form beriku</p>

            </div>
                <form method="POST" action="<?php echo e(route('transaksi.pembayaran')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Form Pembayaran</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row align-items-start">
                                        <div class="col-sm-4">
                                            <label>Nama Bank</label>
                                            <select name="nama_bank" id="class" class="theSelect form-control w-100 ml-0" onchange='checkvalue(this.value)'>
                                                <option hidden disabled selected>--Pilih Bank--</option>
                                                <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item['name']); ?>"><?php echo e($item['name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <option value="lainnya">LAINNYA</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-4">
                                            <label>Nama Pemilik Rekening</label>
                                            <input type="text" class="form-control" name="nama_pemilik"
                                                value=""required>
                                        </div>
                                        <div class="col-sm-4">
                                            <label>Nominal</label>
                                            <input type="text" id="rupiah" class="form-control" name="nominal"
                                                value=""required>
                                        </div>

                                    </div>
                                    <br>
                                    <div class="row" id="lainnya1" style="display: none">
                                        <div class="form-group col-md-12">
                                            <label for="asal_sekolah_text" class="mb-2">Nama BANK</label>
                                            <input type="text" name="nama_bank_text" class="form-control"
                                                placeholder="Masukkan nama bank">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <label class="custom-file-label" for="bukti">Foto bukti pembayaran</label>
                                            <input name="foto" type="file" class="custom-file-input"
                                                aria-describedby="bukti" required>
                                        </div>
                                    </div>
                                    <br>

                                    <br>
                                    <div class="row align-items-start">
                                        <div class="col-md-8"></div>
                                        <div class="col-md-4">
                                            <button type="submit" class="btn btn-block btn-primary">Upload Bukti
                                                Pembayaran</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php elseif($student['status'] == 2): ?>
            <div class="main-title">
                <div class="d-flex">
                    <box-icon name='minus'></box-icon>
                    <p> Pembayaran</p>
                </div>
                <p style="font-size: 15px">Silahkan upload ukti pembayaran anda di form beriku</p>

            </div>
                <form method="POST" action="<?php echo e(route('edit.pembayaran', $student->id)); ?>" enctype="multipart/form-data">
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Form Pembayaran</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row align-items-start">
                                        <div class="col-sm-4">
                                            <label>Nama Bank</label>
                                            <select name="nama_bank" id="class" class="theSelect form-control w-100 ml-0" onchange='checkvalue(this.value)'>
                                                <option hidden disabled selected>--Pilih Bank--</option>
                                                <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item['name']); ?>"><?php echo e($item['name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <option value="lainnya">LAINNYA</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-4">
                                            <label>Nama Pemilik Rekening</label>
                                            <input type="text" class="form-control" name="nama_pemilik"
                                                value=""required>
                                        </div>
                                        <div class="col-sm-4">
                                            <label>Nominal</label>
                                            <input type="text" id="rupiah" class="form-control" name="nominal"
                                                value=""required>
                                        </div>

                                    </div>
                                    <br>
                                    <div class="row" id="lainnya1" style="display: none">
                                        <div class="form-group col-md-12">
                                            <label for="asal_sekolah_text" class="mb-2">Nama BANK</label>
                                            <input type="text" name="nama_bank_text" class="form-control"
                                                placeholder="Masukkan nama bank">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <label class="custom-file-label" for="bukti">Foto bukti pembayaran</label>
                                            <input name="foto" type="file" class="custom-file-input"
                                                aria-describedby="bukti" required>
                                        </div>
                                    </div>
                                    <br>

                                    <br>
                                    <div class="row align-items-start">
                                        <div class="col-md-8"></div>
                                        <div class="col-md-4">
                                            <button type="submit" class="btn btn-block btn-primary">Upload Bukti
                                                Pembayaran</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php elseif($student['status'] == 1): ?>
                <div class="panjul" style="background-color: rgb(16, 210, 16)">
                    <p>Pembayaran di verivikasi, silahkan untuk melanjutkan ke tahap selanjutnya</p>
                </div>
            <?php else: ?>
                <div class="panjul" style="background-color: orange">
                    <p>Pembayaran sedang di verivikasi, harap tunggu informasi selanjutnya</p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script>
        $(".theSelect").select2();
    </script>
    <script>
        function checkvalue(val) {
            if (val === "lainnya") {
                document.getElementById('lainnya1').style.display = 'block';
            } else {
                document.getElementById('lainnya1').style.display = 'none';
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DEV\xampp\htdocs\My-Project\projec_PPDB\resources\views/dashboard/pembayaran.blade.php ENDPATH**/ ?>